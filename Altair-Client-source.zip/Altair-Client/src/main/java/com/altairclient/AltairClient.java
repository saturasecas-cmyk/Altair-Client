package com.altairclient;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AltairClient.MOD_ID)
public final class AltairClient {
    public static final String MOD_ID = "altairclient";

    public AltairClient() {
        FMLJavaModLoadingContext.get().getModEventBus()
            .addListener(this::clientSetup);
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        // Altair Client entry point.
        // Future additions: star-themed menu, client settings, and benign
        // visual/debug utilities after verifying the target Forge API.
    }
}
